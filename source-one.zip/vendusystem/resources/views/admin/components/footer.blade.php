<div class="container-fluid container-fixed-lg footer">
    <div class="copyright sm-text-center">
        <p class="small no-margin pull-left sm-pull-reset"><span class="hint-text">Copyright &copy; 2017</span> <span class="font-montserrat">Vendu Media Creative</span>. <span class="hint-text">All rights reserved.</span> <span class="sm-block"><a class="m-l-10 m-r-10" href="#">Terms of use</a> | <a class="m-l-10" href="#">Privacy Policy</a></span></p>
        <div class="clearfix">
        </div>
    </div>
</div>
