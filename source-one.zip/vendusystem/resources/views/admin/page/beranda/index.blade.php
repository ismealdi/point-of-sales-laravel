@extends('admin.layouts.frame')
@section('title', 'Beranda')
@section('description')
    -
@endsection
@section('button')
    {{--<a href="{{ url('admin/beranda/about/edit') }}" class="btn btn-primary pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-top:-15px;"><i class="fa fa-pencil" style="width:8px;"></i></a>--}}
@endsection


@section('content')


@endsection


@push("script")
<script>

</script>
@endpush
