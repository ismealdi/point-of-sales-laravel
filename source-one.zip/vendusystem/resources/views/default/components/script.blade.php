<script data-pace-options='{ "ajax": true }' src="{{ url('plugins/pace/pace.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery/jquery-1.11.1.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/modernizr.custom.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-ui/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/bootstrapv3/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery/jquery-easy.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-unveil/jquery.unveil.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-bez/jquery.bez.min.js') }}"></script>
<script src="{{ url('plugins/jquery-ios-list/jquery.ioslist.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-actual/jquery.actual.min.js') }}"></script>
<script src="{{ url('plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}"></script>
<script src="{{ url('plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/classie/classie.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/switchery/js/switchery.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/lib/d3.v3.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/nv.d3.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/utils.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/tooltip.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/interactiveLayer.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/axis.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/line.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/lineWithFocusChart.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/mapplic/js/hammer.js') }}"></script>
<script src="{{ url('plugins/mapplic/js/jquery.mousewheel.js') }}"></script>
<script src="{{ url('plugins/mapplic/js/mapplic.js') }}"></script>
<script src="{{ url('plugins/rickshaw/rickshaw.min.js') }}"></script>
<script src="{{ url('plugins/jquery-metrojs/MetroJs.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-sparkline/jquery.sparkline.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/skycons/skycons.js') }}" type="text/javascript"></script>
<script type="text/javascript" src="{{url('plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>
<script src="{{ url('js/pages.min.js') }}"></script>
<script src="{{ url('js/moment.js') }}"></script>
<script src="{{ url('js/scripts.js') }}"></script>