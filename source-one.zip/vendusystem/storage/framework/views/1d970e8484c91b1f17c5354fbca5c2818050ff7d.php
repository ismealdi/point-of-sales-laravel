<?php $__env->startSection('title', 'Edit Service'); ?>
<?php $__env->startSection('description', 'Please make sure to check all input'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(url('/admin/service')); ?>" class="btn btn-info btn-xs no-border">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body sm-p-t-15">

                        <?php echo Form::model($service, [
                          'method' => 'PATCH',
                          'url' => ['/admin/service', $service->id],
                          'files' => true,
                          'id' => 'formValidate',
                          ]); ?>


                        <div class="row">
                            <div class="col-xs-3">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('name', "name"); ?>

                                    <?php echo Form::text('name', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Name"]); ?>

                                </div>
                                <?php echo $errors->first('name', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-3">
                                <div aria-required="true" class="form-group form-group-default form-group-default-select2  required <?php echo e($errors->has('section_order') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('tag', "tag"); ?>

                                    <?php echo Form::select('tag', $tags, null, ['class' => 'full-width', 'data-init-plugin' => 'select2', 'placeholder' => "Tag"]); ?>

                                </div>
                                <?php echo $errors->first('tag', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-2">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('basic') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('basic', "basic"); ?>

                                    <?php echo Form::number('basic', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Basic"]); ?>

                                </div>
                                <?php echo $errors->first('basic', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-2">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('pro') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('pro', "pro"); ?>

                                    <?php echo Form::number('pro', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Pro"]); ?>

                                </div>
                                <?php echo $errors->first('pro', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-2">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('premium') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('premium', "premium"); ?>

                                    <?php echo Form::number('premium', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Premium"]); ?>

                                </div>
                                <?php echo $errors->first('premium', '<label class="error">:message</label>'); ?>

                            </div>
                        </div>

                        <br/>

                        <div class="pull-left m-b-20">
                            <div class="checkbox check-success">
                                <input id="checkbox-agree" type="checkbox" required> <label for="checkbox-agree"><small>Saya sudah mengecek data sebelum menyimpan</small></label>
                            </div>
                        </div>

                        <br/>

                        <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
                        <?php echo Form::submit('SAVE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']); ?>



                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#formValidate').validate();

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>