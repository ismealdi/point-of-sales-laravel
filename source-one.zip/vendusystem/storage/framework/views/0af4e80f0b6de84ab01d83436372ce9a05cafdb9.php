<?php $__env->startSection('title', 'Create Team'); ?>
<?php $__env->startSection('description', 'Please make sure to check all input'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(url('/admin/beranda')); ?>" class="btn btn-info btn-xs no-border">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body sm-p-t-15">
                        <?php echo Form::open(['url' => 'admin/beranda/team', 'id' => 'formValidate', 'files' => true]); ?>


                        <div class="row">
                            <div class="col-xs-4">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('section_title') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('section_title', "name"); ?>

                                    <?php echo Form::text('section_title', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Name"]); ?>

                                </div>
                                <?php echo $errors->first('section_title', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-4">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('section_subtitle') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('section_subtitle', "position"); ?>

                                    <?php echo Form::text('section_subtitle', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Position"]); ?>

                                </div>
                                <?php echo $errors->first('section_subtitle', '<label class="error">:message</label>'); ?>

                            </div>
                            <div class="col-xs-4">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('section_image') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('section_image', "photo"); ?>

                                    <?php echo Form::file('section_images', null, ['class' => 'form-control input-md', 'placeholder' => "Photo"]); ?>

                                </div>
                                <?php echo $errors->first('section_image', '<label class="error">:message</label>'); ?>

                            </div>
                        </div>

                        <br/>

                        <div class="pull-left m-b-20">
                            <div class="checkbox check-success">
                                <input id="checkbox-agree" type="checkbox" required> <label for="checkbox-agree"><small>Saya sudah mengecek data sebelum menyimpan</small></label>
                            </div>
                        </div>

                        <br/>

                        <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
                        <?php echo Form::submit('SAVE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']); ?>



                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#formValidate').validate();

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>