<?php $__env->startSection('title', 'Edit Information'); ?>
<?php $__env->startSection('description', 'Please make sure to check all input'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(url('/admin/beranda')); ?>" class="btn btn-info btn-xs no-border">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body sm-p-t-15">
                        <?php echo Form::model($information, [
                          'method' => 'PATCH',
                          'url' => ['/admin/beranda/about', $information->id],
                          'files' => true,
                          'id' => 'formValidate',
                          ]); ?>


                        <div class="row">
                            <div class="col-md-<?php echo e(($information->section_unique != "points") ? '4' : '10'); ?>">
                                <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('section_title') ? 'has-error' : ''); ?>">
                                    <?php echo Form::label('section_title', $title); ?>

                                    <?php echo Form::text('section_title', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => $title]); ?>

                                </div>
                                <?php echo $errors->first('section_title', '<label class="error">:message</label>'); ?>

                            </div>

                            <?php if($information->section_unique != "points"): ?>
                                <div class="col-md-4">
                                    <div aria-required="true" class="form-group form-group-default  <?php echo e($errors->has('section_subtitle') ? 'has-error' : ''); ?>">
                                        <?php echo Form::label('section_subtitle', $subtitle); ?>

                                        <?php echo Form::text('section_subtitle', null, ['class' => 'form-control input-md', 'placeholder' => $subtitle]); ?>

                                    </div>
                                    <?php echo $errors->first('section_subtitle', '<label class="error">:message</label>'); ?>

                                </div>

                                <div class="col-md-4">
                                    <div aria-required="true" class="form-group form-group-default  <?php echo e($errors->has('section_image') ? 'has-error' : ''); ?>">
                                        <?php echo Form::label('section_image', "photo"); ?>

                                        <?php echo Form::file('section_images', null, ['class' => 'form-control input-md', 'placeholder' => "Photo"]); ?>

                                    </div>
                                    <?php echo $errors->first('section_image', '<label class="error">:message</label>'); ?>

                                </div>
                            <?php else: ?>
                                <div class="col-md-2">
                                    <div aria-required="true" class="form-group form-group-default  <?php echo e($errors->has('section_order') ? 'has-error' : ''); ?>">
                                        <?php echo Form::label('section_order', "order"); ?>

                                        <?php echo Form::number('section_order', null, ['class' => 'form-control input-md', 'placeholder' => $subtitle]); ?>

                                    </div>
                                    <?php echo $errors->first('section_order', '<label class="error">:message</label>'); ?>

                                </div>
                            <?php endif; ?>
                        </div>


                        <textarea name="section_description" class="hidden section_description_value"><?php echo $information->section_description; ?></textarea>
                        <div id="section_description" style="height: 300px;"></div>
                        <br/>

                        <?php if($information->section_unique != "points"): ?>
                        <div class="row" style="background-image: url(<?php echo e(url('files/sections/about/'.$information->section_image)); ?>);background-position: center; background-size: cover;height: 450px">
                            <input type="hidden" name="old_section_image" value="<?php echo e($information->section_image); ?>"/>
                        </div>
                        <br/>
                        <?php endif; ?>

                        <div class="pull-left m-b-20">
                            <div class="checkbox check-success">
                                <input id="checkbox-agree" type="checkbox" required> <label for="checkbox-agree"><small>Saya sudah mengecek data sebelum menyimpan</small></label>
                            </div>
                        </div>

                        <br/>

                        <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
                        <?php echo Form::submit('UPDATE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']); ?>



                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#formValidate').validate();
        $('#section_description').summernote({
            height: 300,                 // set editor height
            minHeight: null,             // set minimum height of editor
            maxHeight: null,             // set maximum height of editor
            focus: true,                  // set focus to editable area after initializing summernote
            onChange: function () {
                $('.section_description_value').val($('.note-editable').html());
            },
        });
        $('.note-editable').html($('.section_description_value').val());

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>