<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(url('img/ic/apple-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(url('img/ic/apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(url('img/ic/apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(url('img/ic/apple-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(url('img/ic/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(url('img/ic/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(url('img/ic/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(url('img/ic/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('img/ic/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(url('img/ic/android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('img/ic/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(url('img/ic/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('img/ic/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(url('img/ic/manifest.json')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(url('img/ic/ms-icon-144x144.png')); ?>">
    <meta name="theme-color" content="#ffffff">

    <title><?php echo $__env->yieldContent('title'); ?> - Vendu Media Creative </title>
    <meta name="Description" content="<?php echo $__env->yieldContent('description', 'Vendu Media Creative Bogor, Jasa Web dan Mobile Developer'); ?>"/>
    <meta name="Keywords" content="<?php echo $__env->yieldContent('tag', 'Digital Agency, Mobile Developer, Web Developer'); ?>">
    <meta  name="Author" content="Vendu Media Creative"/>


    <?php $__env->startSection('header'); ?>
        <?php echo $__env->make('web.components.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

</head>


<body class="smooth-transition boxed no-lines">

    <div class="container-fluid">
        <?php if(Request::get('info') == "Success"): ?>
        <div class="alert alert-success alert-dismissable fade in float-alert text-center">
            <strong>Success!</strong> Pesanmu sudah kami terima, Terimakasih!.
        </div>
        <?php endif; ?>
        <header>
            <div class="container">
                <div class="col-md-3 brand-top">
                    <a class="brand" href="#">VENDU<b>MEDIA</b></a>
                </div>

                <div class="col-md-6 text-center">
                    <div class="nav-trigger">
                        <div class="bar">
                        </div>

                        <div class="bar">
                        </div>

                        <div class="bar">
                        </div>
                    </div>

                    <ul class="navigation">
                        <li>
                            <a class="<?php echo e((Request::is('/')) ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Beranda</a>
                        </li>

                        <li>
                            <a class="<?php echo e((Request::is('services*')) ? 'active' : ''); ?>" href="<?php echo e(url('/services')); ?>">Layanan</a>
                        </li>

                        <li>
                            <a class="<?php echo e((Request::is('blog*')) ? 'active' : ''); ?>" href="<?php echo e(url('/blog')); ?>">Blog</a>
                        </li>

                        <li>
                            <a class="<?php echo e((Request::is('contact')) ? 'active' : ''); ?>" href="<?php echo e(url('/contact')); ?>">Kontak</a>
                        </li>

                        <li class="special">
                            <a href="#">Proposal</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <form>
                        <div class="search input-group">
                            <input class="form-control" placeholder="Search for..." type="text"><span class="input-group-btn"><button class="btn btn-default" type="button"><span class="input-group-btn"><span class="ion-ios-search-strong"></span></span></button></span>
                        </div>
                    </form>
                </div>
            </div>
        </header>

        <?php echo $__env->yieldContent('content'); ?>

        <footer class="top">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-xs-12 text-center">
                        <p>
                            <?php echo $info->location; ?>

                        </p>
                    </div>

                    <div class="col-md-3 col-xs-6 text-center">
                        <p>
                            <a class="__cf_email__" href="mailto:<?php echo e($info->email); ?>"><?php echo e($info->email); ?></a><br>
                            0<?php echo e($info->phone); ?>

                        </p>
                    </div>

                    <div class="col-md-3 col-xs-6 text-center">
                        <p>
                            Mobile Phone / WhatsApp<br/>
                            0<?php echo e($info->mobile); ?>

                        </p>
                    </div>


                    <div class="col-md-3 col-xs-12 text-center">
                        <ul class="social-links">
                            <?php if($info->linkedin != ""): ?>
                            <li>
                                <a class="fa fa-linkedin" href="http://id.linkedin.com/in<?php echo e($info->linkedin); ?>"></a>
                            </li>
                            <?php endif; ?>
                            <?php if($info->instagram != ""): ?>
                            <li>
                                <a class="fa fa-instagram" href="http://instagram.com/<?php echo e($info->instagram); ?>"></a>
                            </li>
                            <?php endif; ?>
                            <?php if($info->facebook != ""): ?>
                            <li>
                                <a class="fa fa-facebook" href="http://facebook.com/<?php echo e($info->facebook); ?>"></a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

        <footer class="bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        &copy; Vendu Media Creative. All rights reserved.<br  class="m-t-20"/>
                        <small>PT. Vendu Crystal Mutiara | SIUP510.41/028/011141/DPMPTTSP/2017 <br/>TDP10.20.1.68.11260 | NPWP81.657.430.5-434.000</small>
                    </div>
                </div>
            </div>
        </footer>

        <div class="filter-container">
            <div class="container">
                <div class="inner">
                    <ul class="filters">
                        <li>
                            <a class="active filter" data-filter="item" href="#">All</a>
                        </li>
                        <?php $__currentLoopData = $projecdes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projecde): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="filter" data-filter="<?php echo e($projecde->section_title); ?>" href="#"><?php echo e(ucwords($projecde->section_title)); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('web.components.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldPushContent('script'); ?>

</html>
