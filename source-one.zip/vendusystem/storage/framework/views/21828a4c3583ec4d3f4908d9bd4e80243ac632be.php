<li class="m-t-30">
    <a class="<?php echo e((Request::is('admin/beranda*')) ? 'active' : ''); ?>" href="<?php echo e(url('admin/beranda')); ?>"><span class="title">Beranda</span></a> <span class=" <?php echo e((Request::is('admin/beranda*')) ? 'bg-success' : ''); ?> icon-thumbnail"><i class="pg-home"></i></span>
</li>

<li>
    <a class="<?php echo e((Request::is('admin/kontak*')) ? 'active' : ''); ?>" href="<?php echo e(url('admin/kontak')); ?>"><span class="title">Kontak</span></a> <span class=" <?php echo e((Request::is('admin/kontak*')) ? 'bg-success' : ''); ?> icon-thumbnail"><i class="pg-telephone"></i></span>
</li>
