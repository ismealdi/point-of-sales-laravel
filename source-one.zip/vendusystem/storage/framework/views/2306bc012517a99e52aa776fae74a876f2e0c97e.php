<?php $__env->startSection('title', 'Informasi Pemilik'); ?>
<?php $__env->startSection('description', 'Informasi lengkap data terpilih'); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(url('/admin/pemilik')); ?>" class="btn btn-info btn-xs no-border">Kembali</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading p-b-15">
                        <div class="panel-title">
                            <?php echo Form::open(['url' => 'admin/pemilik', 'method' => 'get', 'class' => 'form-inline']); ?>

                            Tanggal Dibuat: <?php echo $pemilik->formatedDate($pemilik->created_at); ?><br/>
                            <?php echo Form::close(); ?>

                        </div>
                        <a href="<?php echo e(url('admin/pemilik/'.$pemilik->id.'/edit?back=detail')); ?>" class="btn btn-complete btn-rounded btn-xs  pull-right" type="button" style="height:28px;margin-top: 0px;"><i class="fa fa-pencil"></i></a>
                        <a onClick="deleteData(<?php echo e($pemilik->id); ?>, 'Pemilik')" class="btn btn-danger btn-rounded btn-xs pull-right" type="button" style="height:28px;margin-right:4px;margin-top: 0px;"><i class="fa fa-trash"></i></a>
                        <div class="clearfix"></div>
                    </div>
                    <div class="panel-body b-t b-grey no-padding" style="background: #FFF;">
                        <div class="widget-11-2-table">
                            <table class="table table-hover table-t-b-0">
                                <tbody>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Nama</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->nama); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Telepon</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->telepon); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Toko</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->getToko->nama); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Email</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->getUser->email); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Username</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->getUser->username); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Status</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->getStatus()); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-left b-r b-dashed b-grey">Alamat</td>
                                    <td class="font-montserrat fs-12" width="85%"><?php echo e($pemilik->alamat); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" id="deleteID" />
    <input type="hidden" id="deleteSD" />
<?php $__env->stopSection(); ?>


<?php $__env->startPush("script"); ?>
    <script>
        function deleteData(id, toko) {
            $('#modalDelete').modal('show');
            $('#deleteID').val(id);
            $('#deleteSD').val(toko);
        }

        function hapus(){
            $('#modalDelete').modal('hide');
            var id = $('#deleteID').val();
            var sd = $('#deleteSD').val();
            $.ajax({
                url: '<?php echo e(url("admin/toko")); ?>' + "/" + id + '?' + $.param({"cont": sd, "_token" : '<?php echo e(csrf_token()); ?>' }),
                type: 'DELETE',
                complete: function(data) {
                    $('#'+sd+ id).remove();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>