<?php $__env->startSection('title', $beranda->section_title); ?>
<?php $__env->startSection('description', $beranda->section_description); ?>
<?php $__env->startSection('tag', $beranda->section_subtitle); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div id="services" class="carousel slide carousel-fade " data-ride="carousel">
                        <div class="carousel-inner">
                            <?php $i=0; ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                <div class="item <?php echo e(($i == 1) ? 'active' : ''); ?>">
                                <h1><?php echo e($slider->section_title); ?></h1>
                                <p><?php echo e($slider->section_subtitle); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <ol class="carousel-indicators">
                            <?php for($x=0;$x<count($sliders);$x++): ?>
                            <li data-target="#services" data-slide-to="<?php echo e($x); ?>" class="<?php echo e(($x == 0) ? 'active' : ''); ?>"></li>
                            <?php endfor; ?>
                        </ol>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="background-image: url(<?php echo e(url('files/sections/about/'.$about->section_image)); ?>);height: 550px;background-size: cover; background-position: bottom;background-repeat: no-repeat">

                </div>

                <div class="col-md-9">
                    <div class="box">
                        <h4>
                            <?php echo e($about->section_title); ?>

                        </h4>

                        <h1>
                            <?php echo e($about->section_subtitle); ?>

                        </h1>

                        <p>
                            <?php echo e(strip_tags($about->section_description)); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-lg vcenter">

                    <?php $i=0; ?>
                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <div class="col-md-3 col-sm-6 text-center p-md <?php echo e(($i % 2) ? 'gray-bg' : ''); ?>">
                            <h3>
                                <?php echo e($point->section_title); ?>

                            </h3>

                            <p>
                                <?php echo e(strip_tags($point->section_description)); ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>

    <section class="content ">
        <div class="container mb-xl">
            <div class="row mt-xl">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 text-center">
                        <h4 class="underline">
                            <?php echo e($tag->section_title); ?>

                        </h4>

                        <ul class="label-list">
                            <?php $__currentLoopData = $tag->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($service->section_title); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container mb-xl">
            <div class="row mt-xl">
                <div class="col-md-6 col-md-offset-3 text-center">
                    <h4>
                        <?php echo $team->section_title; ?>

                    </h4>

                    <h3>
                        <?php echo $team->section_subtitle; ?>

                    </h3>
                </div>
            </div>

            <?php $i=0; ?>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i++; ?>
                <?php echo ($i == 1) ? '<div class="row mt-lg">' : ''; ?>

                    <div class="col-md-3 text-center">
                        <img class="fadein <?php echo e(($i % 2) ? 'mb-sm mt-xl' : 'mb-sm mt-sm'); ?>" src="<?php echo e(url('files/sections/teams/'.$team->section_image)); ?>">
                        <h4>
                            <?php echo e($team->section_title); ?>

                        </h4>

                        <p>
                            <?php echo e($team->section_subtitle); ?>

                        </p>
                    </div>
                <?php echo ($i == 4) ? '</div>' : ''; ?>

                <?php $i = ($i == 4) ? 0 : $i; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>

    <section class="grid-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <a class="btn btn-default filter-trigger" href="#">Filter</a>
                </div>

                <div class="col-md-12 grid masonry">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="item <?php echo e($project->taged->section_title); ?> smooth <?php echo e(($project->type == "full") ? "in-view" : ""); ?>" href="">
                        <div class="thumb">
                            <img alt="-" src="<?php echo e(url('files/sections/projects/'.$project->photo)); ?>">
                        </div>

                        <div class="caption">
                            <h4>
                                <?php echo e($project->name); ?>

                            </h4>

                            <div class="tag">
                                <?php echo e($project->taged->section_title); ?>

                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container">
            <div class="row mt-xl mb-xl">
                <div class="col-md-6 ">
                    <h3>
                        <?php echo $salam->section_title; ?>

                    </h3>

                    <?php echo Form::open(['url' => 'hallo?', 'class' => 'form row mt-lg', 'name' => 'form']); ?>

                        <div class="col-md-6">
                            <div class="tag">
                                Siapa nama kamu? * <?php echo $errors->first('name', '| <small class="text-red">:message</small>'); ?>

                            </div>
                            <input class="form-control" name="name" required="" type="text">
                        </div>

                        <div class="col-md-6">
                            <div class="tag">
                                Phone number
                            </div>
                            <input class="form-control" name="phone" type="number">
                        </div>

                        <div class="col-md-6">
                            <div class="tag">
                                E-mail address * <?php echo $errors->first('email', '| <small class="text-red">:message</small>'); ?>

                            </div>
                            <input class="form-control" name="email" required="" type="email">
                        </div>

                        <div class="col-md-6">
                            <div class="tag">
                                Layanan
                            </div>
                            <input class="form-control" name="service" type="text">
                        </div>

                        <div class="col-md-12">
                            <div class="tag">
                                Beri tau kami apa yang ingin kamu bangun? * <?php echo $errors->first('message', '| <small class="text-red">:message</small>'); ?>


                            </div>

                            <textarea class="form-control" name="message" required=""></textarea>

                            <input class="btn btn-default" type="submit" value="Kirim pesan"/><span class="p-md">* wajib diisi loh</span>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
                <div class="col-md-6 text-center">
                    <h3>
                        <?php echo $client->section_title; ?>

                    </h3>

                    <ul class="client">
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($client->section_title); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>


                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("script"); ?>
<script>
    $(document).ready(function(){
        $("#services").carousel({interval: 4250});
        $(".float-alert").fadeTo(2000, 500).slideUp(500, function(){
            $(".float-alert").slideUp(500);
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>