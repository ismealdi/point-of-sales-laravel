
<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('description'); ?>
    <?php echo e($beranda->section_description); ?><br/>
    <small>
        <?php echo e($beranda->section_title); ?> | <?php echo e($beranda->section_subtitle); ?>

    </small>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('button'); ?>
    <a href="<?php echo e(url('admin/beranda/about/'.$beranda->id.'/edit')); ?>" class="btn btn-primary pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-top:-15px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">
            <div class="col-md-8 col-sm-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Slider</h4>
                        </div>

                        <a href="<?php echo e(url('admin/beranda/slider/create')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px"><i class="fa fa-plus" style="width:8px;"></i></a>

                    </div>
                    <div class="panel-body" style="background: #FFF;height: 450px;max-height: 450px;min-height: 450px;">
                        <h5>Daftar Slider</h5>
                        <h6>Jangan lupa untuk di input</h6>
                        <hr/>
                        <div class="auto-overflow widget-11-2-table" style="overflow: auto!important;height: 370px;margin-top: -20px;overflow-x: hidden !important;">
                            <table class="table table-hover">
                                <tbody>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="Slider<?php echo e($slider->id); ?>">
                                        <td width="10%">
                                            <a onClick="deleteData(<?php echo e($slider->id); ?>, 'Slider')" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                            <a href="<?php echo e(url("admin/beranda/slider/".$slider->id."/edit")); ?>" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                                        </td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="5%"><?php echo e($slider->section_order); ?></td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="20%"><?php echo e($slider->section_title); ?></td>
                                        <td class="font-montserrat fs-12 text-left" width="60%"><?php echo e(substr($slider->section_subtitle, 0, 150).".."); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        Jumlah data: <?php echo e(count($sliders)); ?>

                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Tentang</h4>
                        </div>
                        <a href="<?php echo e(url('admin/beranda/about/'.$about->id.'/edit')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-left:4px;"><i class="fa fa-pencil" style="width:8px;"></i></a>

                    </div>
                    <div class="panel-body" style="background: #fbfbfb;height: 450px;max-height: 450px;min-height: 450px;">
                        <h5>Title: <?php echo e($about->section_title); ?></h5>
                        <h6>Sub Title: <?php echo e(substr(strip_tags($about->section_subtitle), 0, 100)); ?></h6>
                        <hr/>
                        <p style="height: 80px;min-height: 80px;max-height: 80px;"><?php echo e(substr(strip_tags($about->section_description), 0, 250)); ?> ... </p>
                        <div class="row" style="background-image: url(<?php echo e(url('files/sections/about/'.$about->section_image)); ?>);background-position: center; background-size: cover;height: 250px">
                            <input type="hidden" name="old_section_image" value="<?php echo e($about->section_image); ?>"/>
                        </div>
                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        Terakhir diperbarui: <?php echo e($about->updated_at); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 no-padding">
                <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-sm-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="panel-title">
                                    <h4 class="m-t-0"><?php echo e($point->section_title); ?></h4>
                                </div>
                                <a href="<?php echo e(url('admin/beranda/about/'.$point->id.'/edit')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-left:4px;"><i class="fa fa-pencil" style="width:8px;"></i></a>

                            </div>
                            <div class="panel-body" style="background: #fbfbfb;height: 150px;max-height: 150px;min-height: 150px;">
                                <p style="height: 80px;min-height: 80px;max-height: 80px;"><?php echo e(substr(strip_tags($point->section_description), 0, 250)); ?> ... </p>
                            </div>
                            <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                                Terakhir diperbarui: <?php echo e($point->updated_at); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-md-4 col-sm-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Layanan</h4>
                        </div>

                        <a href="<?php echo e(url('admin/beranda/service/tag/show')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-left:4px"><i class="fa fa-tag" style="width:8px;"></i></a>
                        <a href="<?php echo e(url('admin/beranda/service/create')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px"><i class="fa fa-plus" style="width:8px;"></i></a>

                    </div>
                    <div class="panel-body" style="background: #FFF;height: 435px;max-height: 435px;min-height: 435px;">
                        <h5>Daftar Layanan</h5>
                        <h6>Untuk menambahkan daftar tag</h6>
                        <hr/>
                        <div class="auto-overflow widget-11-2-table" style="overflow: auto!important;height: 350px;margin-top: -20px;overflow-x: hidden !important;">
                            <table class="table table-hover">
                                <tbody>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="Service<?php echo e($service->id); ?>">
                                        <td width="15%">
                                            <a onClick="deleteData(<?php echo e($service->id); ?>, 'Service')" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                            <a href="<?php echo e(url("admin/beranda/service/".$service->id."/edit")); ?>" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                                        </td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="15%"><?php echo e($service->tag->section_title); ?></td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="25%"><?php echo e($service->section_title); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        Jumlah data: <?php echo e(count($services)); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-sm-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Team</h4>
                        </div>

                        <a href="<?php echo e(url('admin/beranda/about/'.$team->id.'/edit')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-left:4px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                        <a href="<?php echo e(url('admin/beranda/team/create')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px"><i class="fa fa-plus" style="width:8px;"></i></a>

                    </div>
                    <div class="panel-body" style="background: #FFF;height: 450px;max-height: 450px;min-height: 450px;">
                        <h5>Daftar Team</h5>
                        <h6>Jangan lupa untuk di input</h6>
                        <hr/>
                        <div class="auto-overflow widget-11-2-table" style="overflow: auto!important;height: 370px;margin-top: -20px;overflow-x: hidden !important;">
                            <table class="table table-hover">
                                <tbody>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="Team<?php echo e($team->id); ?>">
                                        <td width="10%">
                                            <a onClick="deleteData(<?php echo e($team->id); ?>, 'Team')" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                            <a href="<?php echo e(url("admin/beranda/team/".$team->id."/edit")); ?>" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                                        </td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="30%"><?php echo e($team->section_title); ?></td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="20%"><?php echo e($team->section_subtitle); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        Jumlah data: <?php echo e(count($teams)); ?>

                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Klien</h4>
                        </div>

                        <a href="<?php echo e(url('admin/beranda/about/'.$client->id.'/edit')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-left:4px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                        <a href="<?php echo e(url('admin/beranda/client/create')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px"><i class="fa fa-plus" style="width:8px;"></i></a>

                    </div>
                    <div class="panel-body" style="background: #FFF;height: 450px;max-height: 450px;min-height: 450px;">
                        <h5>Daftar Klien</h5>
                        <h6>Jangan lupa di tambahkan</h6>
                        <hr/>
                        <div class="auto-overflow widget-11-2-table" style="overflow: auto!important;height: 370px;margin-top: -20px;overflow-x: hidden !important;">
                            <table class="table table-hover">
                                <tbody>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="Client<?php echo e($client->id); ?>">
                                        <td width="15%">
                                            <a onClick="deleteData(<?php echo e($client->id); ?>, 'Client')" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                            <a href="<?php echo e(url("admin/beranda/client/".$client->id."/edit")); ?>" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;"><i class="fa fa-pencil" style="width:8px;"></i></a>
                                        </td>
                                        <td class="font-montserrat all-caps fs-12 text-left" width="25%"><?php echo e($client->section_title); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        Jumlah data: <?php echo e(count($clients)); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <input type="hidden" id="deleteID" />
    <input type="hidden" id="deleteSD" />
<?php $__env->stopSection(); ?>


<?php $__env->startPush("script"); ?>
<script>
    function deleteData(id, service) {
        $('#modalDelete').modal('show');
        $('#deleteID').val(id);
        $('#deleteSD').val(service);
    }

    function hapus(){
        $('#modalDelete').modal('hide');
        var id = $('#deleteID').val();
        var sd = $('#deleteSD').val();
        $.ajax({
            url: '<?php echo e(url("admin/beranda/slider")); ?>' + "/" + id + '?' + $.param({"_token" : '<?php echo e(csrf_token()); ?>' }),
            type: 'DELETE',
            complete: function(data) {
                $('#'+sd+ id).remove();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>